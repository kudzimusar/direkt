import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import type { PoolClient } from 'pg';
import type { AuthenticatedActor } from '../authorization/authenticated-actor';
import { DatabaseService } from '../platform/database/database.service';
import type { CreateContactHandoffDto } from './interaction-handoff.dto';
import type {
  ContactHandoffChannel,
  ContactHandoffView,
  EffectiveContactHandoffStatus,
  ProviderInteractionListView,
  ReviewEligibilityView,
  TrackedInteractionEventView,
  TrackedInteractionStatus,
  TrackedInteractionView,
} from './interaction-handoff.types';

interface HandoffScopeRow {
  interaction_id: string;
  enquiry_id: string;
  customer_identity_id: string;
  provider_id: string;
  contact_id: string;
  contact_display_hint: string;
}

interface HandoffRow {
  handoff_id: string;
  interaction_id: string;
  enquiry_id: string;
  channel: ContactHandoffChannel;
  contact_display_hint: string;
  stored_status: 'active' | 'revoked';
  consented_at: Date;
  expires_at: Date;
  revoked_at: Date | null;
  policy_version: string;
  delivery_state: 'disabled';
}

interface InteractionRow {
  interaction_id: string;
  enquiry_id: string;
  public_provider_id: string;
  provider_display_name: string;
  category_key: string;
  category_name: string;
  status: TrackedInteractionStatus;
  revision: number;
  started_at: Date;
  completed_at: Date | null;
  cancelled_at: Date | null;
  review_eligible_from: Date | null;
  review_eligible_until: Date | null;
  review_exists: boolean;
}

interface InteractionEventRow {
  id: string;
  sequence: number;
  event_type: TrackedInteractionEventView['eventType'];
  actor_kind: TrackedInteractionEventView['actorKind'];
  reason: string;
  policy_version: string;
  occurred_at: Date;
}

interface ExistingHandoffRow {
  handoff_id: string;
  request_fingerprint: string;
}

@Injectable()
export class InteractionHandoffRepository {
  constructor(private readonly database: DatabaseService) {}

  createHandoff(
    actor: AuthenticatedActor,
    enquiryId: string,
    dto: CreateContactHandoffDto,
    keyHash: string,
    requestFingerprint: string,
    requestId?: string,
  ): Promise<ContactHandoffView> {
    return this.database
      .transaction(async (client) => {
        await client.query(`SELECT pg_advisory_xact_lock(hashtextextended($1 || ':' || $2, 0))`, [
          actor.identityId,
          keyHash,
        ]);
        const existing = await client.query<ExistingHandoffRow>(
          `SELECT handoffs.id AS handoff_id, consents.request_fingerprint
         FROM interaction.contact_consents AS consents
         JOIN interaction.contact_handoffs AS handoffs ON handoffs.consent_id = consents.id
         WHERE consents.customer_identity_id = $1
           AND consents.idempotency_key_hash = $2
         FOR UPDATE OF consents, handoffs`,
          [actor.identityId, keyHash],
        );
        const replay = existing.rows[0];
        if (replay) {
          if (replay.request_fingerprint !== requestFingerprint) {
            throw new ConflictException(
              'The idempotency key already exists with a different handoff request.',
            );
          }
          return this.loadCustomerHandoff(client, replay.handoff_id, actor.identityId);
        }

        await client.query(`SELECT pg_advisory_xact_lock(hashtextextended($1 || ':' || $2, 0))`, [
          enquiryId,
          dto.channel,
        ]);
        const scope = await this.resolveCustomerHandoffScope(
          client,
          actor.identityId,
          enquiryId,
          dto.contactId,
        );
        const insertedConsent = await client.query<{ id: string; expires_at: Date }>(
          `INSERT INTO interaction.contact_consents (
           interaction_id,
           enquiry_id,
           customer_identity_id,
           provider_id,
           contact_id,
           channel,
           contact_display_hint,
           policy_version,
           idempotency_key_hash,
           request_fingerprint,
           expires_at
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, now() + interval '24 hours')
         RETURNING id, expires_at`,
          [
            scope.interaction_id,
            scope.enquiry_id,
            scope.customer_identity_id,
            scope.provider_id,
            scope.contact_id,
            dto.channel,
            scope.contact_display_hint,
            dto.policyVersion.trim(),
            keyHash,
            requestFingerprint,
          ],
        );
        const consent = insertedConsent.rows[0];
        if (!consent) {
          throw new Error('Contact consent creation returned no identifier.');
        }
        const insertedHandoff = await client.query<{ id: string }>(
          `INSERT INTO interaction.contact_handoffs (
           consent_id,
           interaction_id,
           enquiry_id,
           customer_identity_id,
           provider_id,
           channel,
           contact_display_hint,
           expires_at
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         RETURNING id`,
          [
            consent.id,
            scope.interaction_id,
            scope.enquiry_id,
            scope.customer_identity_id,
            scope.provider_id,
            dto.channel,
            scope.contact_display_hint,
            consent.expires_at,
          ],
        );
        const handoffId = insertedHandoff.rows[0]?.id;
        if (!handoffId) {
          throw new Error('Contact handoff creation returned no identifier.');
        }
        await this.audit(client, {
          actorIdentityId: actor.identityId,
          providerId: scope.provider_id,
          requestId,
          action: 'interaction_contact_handoff_created',
          resourceType: 'contact_handoff',
          resourceId: handoffId,
          metadata: {
            interactionId: scope.interaction_id,
            enquiryId,
            channel: dto.channel,
            expiresAt: consent.expires_at.toISOString(),
            contactValueStored: false,
            externalDeliveryAttempted: false,
            trustOrPublicationMutation: false,
          },
        });
        return this.loadCustomerHandoff(client, handoffId, actor.identityId);
      })
      .catch((error: unknown) => {
        const pgError = error as { code?: string; constraint?: string };
        if (pgError.code === '23P01') {
          throw new ConflictException(
            'A current contact handoff already exists for this interaction and channel.',
          );
        }
        throw error;
      });
  }

  listCustomerHandoffs(
    actor: AuthenticatedActor,
    enquiryId: string,
  ): Promise<ContactHandoffView[]> {
    return this.database.transaction(async (client) => {
      await this.assertCustomerEnquiry(client, enquiryId, actor.identityId);
      const result = await client.query<HandoffRow>(
        `${this.handoffQuery()}
         WHERE handoffs.enquiry_id = $1 AND handoffs.customer_identity_id = $2
         ORDER BY handoffs.created_at DESC`,
        [enquiryId, actor.identityId],
      );
      return result.rows.map((row) => this.toHandoffView(row));
    });
  }

  providerHandoff(actor: AuthenticatedActor, enquiryId: string): Promise<ContactHandoffView> {
    return this.database.transaction(async (client) => {
      const providerId = await this.resolveProviderContext(client, actor.identityId);
      const result = await client.query<HandoffRow>(
        `${this.handoffQuery()}
         WHERE handoffs.enquiry_id = $1
           AND handoffs.provider_id = $2
           AND handoffs.status = 'active'
           AND consents.status = 'active'
           AND handoffs.expires_at > now()
         ORDER BY handoffs.created_at DESC
         LIMIT 1`,
        [enquiryId, providerId],
      );
      const row = result.rows[0];
      if (!row) {
        throw new NotFoundException(
          'No current consent-scoped contact handoff exists for this enquiry.',
        );
      }
      return this.toHandoffView(row);
    });
  }

  revokeHandoff(
    actor: AuthenticatedActor,
    enquiryId: string,
    handoffId: string,
    reason: string,
    policyVersion: string,
    requestId?: string,
  ): Promise<ContactHandoffView> {
    return this.database.transaction(async (client) => {
      await this.assertCustomerEnquiry(client, enquiryId, actor.identityId);
      try {
        await client.query(`SELECT (interaction.revoke_contact_handoff($1, $2, $3, $4)).id`, [
          handoffId,
          actor.identityId,
          reason.trim(),
          policyVersion.trim(),
        ]);
      } catch (error) {
        const message = error instanceof Error ? error.message : '';
        if (message.includes('not found')) {
          throw new NotFoundException('The contact handoff was not found in the customer scope.');
        }
        throw error;
      }
      const handoff = await this.loadCustomerHandoff(client, handoffId, actor.identityId);
      await this.audit(client, {
        actorIdentityId: actor.identityId,
        providerId: await this.providerIdForEnquiry(client, enquiryId),
        requestId,
        action: 'interaction_contact_handoff_revoked',
        resourceType: 'contact_handoff',
        resourceId: handoffId,
        metadata: {
          enquiryId,
          channel: handoff.channel,
          reason: reason.trim(),
          policyVersion: policyVersion.trim(),
          externalDeliveryAttempted: false,
        },
      });
      return handoff;
    });
  }

  listCustomerInteractions(actor: AuthenticatedActor): Promise<TrackedInteractionView[]> {
    return this.database.transaction(async (client) => {
      const ids = await client.query<{ id: string }>(
        `SELECT id
         FROM interaction.tracked_interactions
         WHERE customer_identity_id = $1
         ORDER BY updated_at DESC, id DESC
         LIMIT 100`,
        [actor.identityId],
      );
      return Promise.all(
        ids.rows.map((row) => this.loadInteraction(client, row.id, 'customer', actor.identityId)),
      );
    });
  }

  customerInteraction(
    actor: AuthenticatedActor,
    interactionId: string,
  ): Promise<TrackedInteractionView> {
    return this.database.transaction((client) =>
      this.loadInteraction(client, interactionId, 'customer', actor.identityId),
    );
  }

  providerInteractions(actor: AuthenticatedActor): Promise<ProviderInteractionListView> {
    return this.database.transaction(async (client) => {
      const providerId = await this.resolveProviderContext(client, actor.identityId);
      const ids = await client.query<{ id: string }>(
        `SELECT id
         FROM interaction.tracked_interactions
         WHERE provider_id = $1
         ORDER BY
           CASE status WHEN 'active' THEN 1 WHEN 'completed' THEN 2 ELSE 3 END,
           updated_at DESC,
           id DESC
         LIMIT 200`,
        [providerId],
      );
      return {
        providerScope: 'actor_resolved',
        items: await Promise.all(
          ids.rows.map((row) => this.loadInteraction(client, row.id, 'provider', providerId)),
        ),
      };
    });
  }

  reviewEligibility(
    actor: AuthenticatedActor,
    interactionId: string,
  ): Promise<ReviewEligibilityView> {
    return this.database.transaction(async (client) => {
      const view = await this.loadInteraction(client, interactionId, 'customer', actor.identityId);
      return view.reviewEligibility;
    });
  }

  private async resolveCustomerHandoffScope(
    client: PoolClient,
    customerIdentityId: string,
    enquiryId: string,
    contactId: string,
  ): Promise<HandoffScopeRow> {
    const result = await client.query<HandoffScopeRow>(
      `SELECT
         tracked.id AS interaction_id,
         enquiries.id AS enquiry_id,
         enquiries.customer_identity_id,
         enquiries.provider_id,
         contacts.id AS contact_id,
         contacts.display_hint AS contact_display_hint
       FROM interaction.enquiries AS enquiries
       JOIN interaction.tracked_interactions AS tracked ON tracked.enquiry_id = enquiries.id
       JOIN account.contacts AS contacts
         ON contacts.id = $3
        AND contacts.identity_id = enquiries.customer_identity_id
        AND contacts.channel = 'phone'
        AND contacts.verified_at IS NOT NULL
       WHERE enquiries.id = $1
         AND enquiries.customer_identity_id = $2
         AND enquiries.status = 'accepted'
         AND tracked.status = 'active'
       FOR UPDATE OF enquiries, tracked, contacts`,
      [enquiryId, customerIdentityId, contactId],
    );
    const scope = result.rows[0];
    if (!scope) {
      const owned = await client.query<{ status: string }>(
        `SELECT status FROM interaction.enquiries WHERE id = $1 AND customer_identity_id = $2`,
        [enquiryId, customerIdentityId],
      );
      if (!owned.rows[0]) {
        throw new NotFoundException('The enquiry was not found in the customer scope.');
      }
      if (owned.rows[0].status !== 'accepted') {
        throw new ConflictException('The provider must accept the enquiry before contact handoff.');
      }
      throw new BadRequestException('A current verified customer phone contact is required.');
    }
    return scope;
  }

  private async assertCustomerEnquiry(
    client: PoolClient,
    enquiryId: string,
    customerIdentityId: string,
  ): Promise<void> {
    const result = await client.query(
      `SELECT 1 FROM interaction.enquiries WHERE id = $1 AND customer_identity_id = $2`,
      [enquiryId, customerIdentityId],
    );
    if (!result.rowCount) {
      throw new NotFoundException('The enquiry was not found in the customer scope.');
    }
  }

  private async providerIdForEnquiry(client: PoolClient, enquiryId: string): Promise<string> {
    const result = await client.query<{ provider_id: string }>(
      `SELECT provider_id FROM interaction.enquiries WHERE id = $1`,
      [enquiryId],
    );
    const providerId = result.rows[0]?.provider_id;
    if (!providerId) {
      throw new NotFoundException('The enquiry was not found.');
    }
    return providerId;
  }

  private async loadCustomerHandoff(
    client: PoolClient,
    handoffId: string,
    customerIdentityId: string,
  ): Promise<ContactHandoffView> {
    const result = await client.query<HandoffRow>(
      `${this.handoffQuery()}
       WHERE handoffs.id = $1 AND handoffs.customer_identity_id = $2`,
      [handoffId, customerIdentityId],
    );
    const row = result.rows[0];
    if (!row) {
      throw new NotFoundException('The contact handoff was not found in the customer scope.');
    }
    return this.toHandoffView(row);
  }

  private handoffQuery(): string {
    return `SELECT
       handoffs.id AS handoff_id,
       handoffs.interaction_id,
       handoffs.enquiry_id,
       handoffs.channel,
       handoffs.contact_display_hint,
       handoffs.status AS stored_status,
       consents.consented_at,
       handoffs.expires_at,
       handoffs.revoked_at,
       consents.policy_version,
       handoffs.delivery_state
     FROM interaction.contact_handoffs AS handoffs
     JOIN interaction.contact_consents AS consents ON consents.id = handoffs.consent_id`;
  }

  private toHandoffView(row: HandoffRow): ContactHandoffView {
    const status: EffectiveContactHandoffStatus =
      row.stored_status === 'revoked'
        ? 'revoked'
        : row.expires_at.getTime() <= Date.now()
          ? 'expired'
          : 'active';
    return {
      handoffId: row.handoff_id,
      interactionId: row.interaction_id,
      enquiryId: row.enquiry_id,
      channel: row.channel,
      contactDisplayHint: row.contact_display_hint,
      status,
      consentedAt: row.consented_at.toISOString(),
      expiresAt: row.expires_at.toISOString(),
      revokedAt: row.revoked_at?.toISOString() ?? null,
      policyVersion: row.policy_version,
      deliveryState: row.delivery_state,
      externalDeliveryAttempted: false,
      rawContactIncluded: false,
      synthetic: true,
    };
  }

  private async loadInteraction(
    client: PoolClient,
    interactionId: string,
    scope: 'customer' | 'provider',
    scopeValue: string,
  ): Promise<TrackedInteractionView> {
    const scopeSql =
      scope === 'customer' ? 'tracked.customer_identity_id = $2' : 'tracked.provider_id = $2';
    const result = await client.query<InteractionRow>(
      `SELECT
         tracked.id AS interaction_id,
         tracked.enquiry_id,
         publications.id AS public_provider_id,
         profiles.display_name AS provider_display_name,
         categories.category_key,
         categories.name AS category_name,
         tracked.status,
         tracked.revision,
         tracked.started_at,
         tracked.completed_at,
         tracked.cancelled_at,
         tracked.review_eligible_from,
         tracked.review_eligible_until,
         EXISTS (
           SELECT 1 FROM interaction.reviews WHERE interaction_id = tracked.id
         ) AS review_exists
       FROM interaction.tracked_interactions AS tracked
       JOIN interaction.enquiries AS enquiries ON enquiries.id = tracked.enquiry_id
       JOIN discovery.publications AS publications ON publications.id = tracked.publication_id
       JOIN provider.profiles AS profiles ON profiles.provider_id = tracked.provider_id
       JOIN catalog.service_categories AS categories ON categories.id = tracked.category_id
       WHERE tracked.id = $1 AND ${scopeSql}`,
      [interactionId, scopeValue],
    );
    const row = result.rows[0];
    if (!row) {
      throw new NotFoundException(
        'The tracked interaction was not found in the authenticated scope.',
      );
    }
    const [events, handoffs] = await Promise.all([
      client.query<InteractionEventRow>(
        `SELECT id, sequence, event_type, actor_kind, reason, policy_version, occurred_at
         FROM interaction.interaction_events
         WHERE interaction_id = $1
         ORDER BY sequence`,
        [interactionId],
      ),
      client.query<HandoffRow>(
        `${this.handoffQuery()}
         WHERE handoffs.interaction_id = $1
         ORDER BY handoffs.created_at`,
        [interactionId],
      ),
    ]);
    return {
      interactionId: row.interaction_id,
      enquiryId: row.enquiry_id,
      publicProviderId: row.public_provider_id,
      providerDisplayName: row.provider_display_name,
      categoryKey: row.category_key,
      categoryName: row.category_name,
      status: row.status,
      revision: row.revision,
      startedAt: row.started_at.toISOString(),
      completedAt: row.completed_at?.toISOString() ?? null,
      cancelledAt: row.cancelled_at?.toISOString() ?? null,
      reviewEligibility: this.eligibility(row),
      handoffs: handoffs.rows.map((handoff) => this.toHandoffView(handoff)),
      events: events.rows.map((event): TrackedInteractionEventView => ({
        eventId: event.id,
        sequence: event.sequence,
        eventType: event.event_type,
        actorKind: event.actor_kind,
        reason: event.reason,
        policyVersion: event.policy_version,
        occurredAt: event.occurred_at.toISOString(),
        actorIdentityExposed: false,
        privateMetadataIncluded: false,
      })),
      customerContactIncluded: false,
      privateEvidenceIncluded: false,
      internalModerationIncluded: false,
      synthetic: true,
    };
  }

  private eligibility(row: InteractionRow): ReviewEligibilityView {
    if (row.review_exists) {
      return {
        eligible: false,
        reasonCode: 'ALREADY_REVIEWED',
        eligibleFrom: row.review_eligible_from?.toISOString() ?? null,
        eligibleUntil: row.review_eligible_until?.toISOString() ?? null,
      };
    }
    if (row.status === 'active') {
      return {
        eligible: false,
        reasonCode: 'INTERACTION_ACTIVE',
        eligibleFrom: null,
        eligibleUntil: null,
      };
    }
    if (row.status === 'cancelled') {
      return {
        eligible: false,
        reasonCode: 'INTERACTION_CANCELLED',
        eligibleFrom: null,
        eligibleUntil: null,
      };
    }
    const now = Date.now();
    const from = row.review_eligible_from?.getTime() ?? Number.POSITIVE_INFINITY;
    const until = row.review_eligible_until?.getTime() ?? Number.NEGATIVE_INFINITY;
    if (now < from) {
      return {
        eligible: false,
        reasonCode: 'WINDOW_NOT_OPEN',
        eligibleFrom: row.review_eligible_from?.toISOString() ?? null,
        eligibleUntil: row.review_eligible_until?.toISOString() ?? null,
      };
    }
    if (now >= until) {
      return {
        eligible: false,
        reasonCode: 'WINDOW_EXPIRED',
        eligibleFrom: row.review_eligible_from?.toISOString() ?? null,
        eligibleUntil: row.review_eligible_until?.toISOString() ?? null,
      };
    }
    return {
      eligible: true,
      reasonCode: 'ELIGIBLE',
      eligibleFrom: row.review_eligible_from?.toISOString() ?? null,
      eligibleUntil: row.review_eligible_until?.toISOString() ?? null,
    };
  }

  private async resolveProviderContext(client: PoolClient, identityId: string): Promise<string> {
    const result = await client.query<{ provider_id: string }>(
      `SELECT DISTINCT assignments.provider_id
       FROM authz.role_assignments AS assignments
       JOIN authz.roles AS roles ON roles.id = assignments.role_id
       WHERE assignments.identity_id = $1
         AND assignments.scope_type = 'provider'
         AND assignments.provider_id IS NOT NULL
         AND assignments.revoked_at IS NULL
         AND assignments.starts_at <= now()
         AND (assignments.ends_at IS NULL OR assignments.ends_at > now())
         AND roles.role_key IN ('provider_owner', 'provider_member', 'provider_responder')
       ORDER BY assignments.provider_id
       LIMIT 2`,
      [identityId],
    );
    if (result.rows.length === 0) {
      throw new NotFoundException('The authenticated identity has no active provider workspace.');
    }
    if (result.rows.length > 1) {
      throw new ConflictException(
        'The authenticated identity has more than one active provider workspace.',
      );
    }
    return (result.rows[0] as { provider_id: string }).provider_id;
  }

  private async audit(
    client: PoolClient,
    event: {
      actorIdentityId: string;
      providerId: string;
      requestId: string | undefined;
      action: string;
      resourceType: string;
      resourceId: string;
      metadata: Record<string, unknown>;
    },
  ): Promise<void> {
    await client.query(
      `INSERT INTO platform.audit_events (
         request_id,
         actor_type,
         actor_id,
         provider_id,
         action,
         resource_type,
         resource_id,
         outcome,
         metadata
       ) VALUES ($1, 'identity', $2, $3, $4, $5, $6, 'success', $7::jsonb)`,
      [
        event.requestId ?? null,
        event.actorIdentityId,
        event.providerId,
        event.action,
        event.resourceType,
        event.resourceId,
        JSON.stringify(event.metadata),
      ],
    );
  }
}
